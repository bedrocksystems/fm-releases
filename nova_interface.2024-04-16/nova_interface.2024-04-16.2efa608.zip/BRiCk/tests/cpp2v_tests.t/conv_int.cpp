enum Foo : unsigned int { FOO = 0 };

enum Bar : signed long long { BAR = 0 };
