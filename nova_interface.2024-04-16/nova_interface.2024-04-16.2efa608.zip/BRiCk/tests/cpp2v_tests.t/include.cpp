#include "include.hpp"

class C { int x; };

void g(const int) {}

int h(volatile int, ...) { return 0; }
