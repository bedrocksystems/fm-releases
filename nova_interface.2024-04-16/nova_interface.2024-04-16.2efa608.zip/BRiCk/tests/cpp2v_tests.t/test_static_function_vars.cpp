void foo() {
  static int GLOBAL = 0;
}
