class C;

void f(C*);

void g(int);

int h(int, ...);

int h();
