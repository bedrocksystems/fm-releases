int test() {
  switch (int x = 0) {
  case 0: return 1;
  default: return 0;
  }
}
