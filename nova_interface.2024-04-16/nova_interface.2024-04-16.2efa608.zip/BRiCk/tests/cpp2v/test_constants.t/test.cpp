/*
 * Copyright (C) BedRock Systems Inc. 2019
 *
 * SPDX-License-Identifier:MIT-0
 */

const int iX = 1;
const unsigned int uY = 100;
constexpr long long BIG = 10000;
constexpr char c = 'a';
constexpr long l = 1 + 1;
