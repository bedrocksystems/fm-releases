/*
 * Copyright (C) BedRock Systems Inc. 2019
 *
 * SPDX-License-Identifier:MIT-0
 */

namespace Foo {
    int foo(int x) { return x; }
}

namespace Bar {
    int foo(int x) { return x + 1; }
}
