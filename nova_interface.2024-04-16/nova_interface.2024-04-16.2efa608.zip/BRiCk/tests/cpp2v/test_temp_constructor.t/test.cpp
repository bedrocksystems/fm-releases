/*
 * Copyright (C) BedRock Systems Inc. 2019
 *
 * SPDX-License-Identifier:MIT-0
 */

struct Foo {
  Foo(int x=5) { }
};

void foo() {
  Foo();
}
