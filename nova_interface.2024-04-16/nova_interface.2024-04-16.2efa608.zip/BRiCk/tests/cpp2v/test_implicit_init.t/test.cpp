/*
 * Copyright (C) BedRock Systems Inc. 2019
 *
 * SPDX-License-Identifier:MIT-0
 */

class Con {
    char bar[33];

    Con() : bar()
    {}
};
