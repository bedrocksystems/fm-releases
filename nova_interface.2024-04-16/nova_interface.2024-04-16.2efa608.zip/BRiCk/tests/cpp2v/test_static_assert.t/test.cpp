static_assert(true, "is true");
static_assert(true);

