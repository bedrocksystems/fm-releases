/*
 * Copyright (C) BedRock Systems Inc. 2019
 *
 * SPDX-License-Identifier:MIT-0
 */

class Point {
private:
    int x, y;

public:
    Point() {
        x = 0;
        y = 0;
    }
    ~Point() {}
};
