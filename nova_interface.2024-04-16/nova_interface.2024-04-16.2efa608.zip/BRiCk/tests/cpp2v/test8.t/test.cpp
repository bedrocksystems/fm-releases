/*
 * Copyright (C) BedRock Systems Inc. 2019
 *
 * SPDX-License-Identifier:MIT-0
 */

extern "C" {
    int foo(int, int);
    int bar(int, int);
};

extern int fibble;
