/*
 * Copyright (C) BedRock Systems Inc. 2019
 *
 * SPDX-License-Identifier:MIT-0
 */

void test() {
    const char* q = "";
    const char* p = "\"hello\0\n\r";
    const char* bar = "bye \xE2\x84\xA2 \u2122";
}
