/*
 * Copyright (C) BedRock Systems Inc. 2019
 *
 * SPDX-License-Identifier:MIT-0
 */

void test() {
    unsigned int ui = 0xffffffffu;
    signed int si = 0xffffffff;
    unsigned long long ull = 0xffffffffffffffffu;
    signed long long sll = 0xffffffffffffffffu;

    int i = -1;
    int j = -2147483647;
}
