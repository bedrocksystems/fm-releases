/*
 * Copyright (C) BedRock Systems Inc. 2019
 *
 * SPDX-License-Identifier:MIT-0
 */

typedef int Foo;

Foo test() {
    return 1;
}
