namespace XXX {

  extern "C++" {
    int foo() { return 0; }
  }
  extern "C" {
    int bar() { return 1; }
  }

}
