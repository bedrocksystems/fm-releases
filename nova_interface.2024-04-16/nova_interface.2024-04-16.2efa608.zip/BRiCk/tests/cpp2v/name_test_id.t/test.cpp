/*
 * Copyright (c) 2024 BedRock Systems, Inc.
 * This software is distributed under the terms of the BedRock Open-Source License.
 * See the LICENSE-BedRock file in the repository root for details.
 */

// Cover names that become `Nid`

namespace ns{
    struct inhabit;
}
class c;
struct s;
union u;
enum e1 {};
enum class e2 {};
typedef int t1;
using t2 = int;
int v;
