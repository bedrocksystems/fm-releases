/*
 * Copyright (C) BedRock Systems Inc. 2019
 *
 * SPDX-License-Identifier:MIT-0
 */

int main() {
    int a, b, c;
    a += b;
    a -= b;
    a++;
    a--;
    --a;
    ++a;
    a = b;
    a %= b;
    a *= b;
    a ^= b;
    a &= b;
    a |= b;
    c= a + b;
    c=a - b;
    c=a * b;
    c=a / b;
    c=a % b;
    return c;
}
