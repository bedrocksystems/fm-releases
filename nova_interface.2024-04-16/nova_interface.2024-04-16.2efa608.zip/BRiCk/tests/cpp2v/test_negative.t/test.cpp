/*
 * Copyright (C) BedRock Systems Inc. 2019
 *
 * SPDX-License-Identifier:MIT-0
 */

int test() {
    int x = -1;
    int y = x + -3;
    return y;
}
