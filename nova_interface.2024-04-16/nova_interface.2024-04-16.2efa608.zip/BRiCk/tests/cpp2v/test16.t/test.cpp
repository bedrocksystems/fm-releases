/*
 * Copyright (C) BedRock Systems Inc. 2019
 *
 * SPDX-License-Identifier:MIT-0
 */

void test() {
    if (int x = 0) {
        x++;
    } else {
        --x;
    }
    while(int x = 5) {
        x--;
    }

}
