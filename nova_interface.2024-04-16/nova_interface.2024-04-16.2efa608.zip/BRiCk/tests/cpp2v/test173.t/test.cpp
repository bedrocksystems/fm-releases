class Con {
    char bar[33];

    Con() : bar()
    {}
};
