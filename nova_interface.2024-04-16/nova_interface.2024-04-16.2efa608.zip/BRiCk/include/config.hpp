// Print [Talias] nodes for aliases
#define PRINT_ALIAS 0
// Print [Dtypedef] nodes for [typedef] and [using]
#define PRINT_TYPEDEF 0