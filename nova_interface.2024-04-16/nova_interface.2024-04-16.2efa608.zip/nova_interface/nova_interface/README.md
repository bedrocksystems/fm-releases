# nova_interface

This directory contains formal specs for NOVA. This includes:

- a first-order, operational specification of the ABI, for details like register
  parsing for syscalls, codes, portal numbers used for implicit calls, etc.
- separation-logic specifications of the syscall behavior.
- a separation-logic specification of a user code program (an EC) running atop NOVA.

The formal specification is intended to be up-to-date with the [NOVA Microhypervisor Interface Specification (December 1, 2023)](https://github.com/udosteinberg/NOVA/blob/7c7e507d791cec767529e9c3b723a07ad5cd1e03/doc/specification.pdf) (NOVA IFSPEC).

## Hypercall specs

Hypercall specs are broken up into layers:

- [bedrock.nova_interface.model](./model.v): NOVA types, generally by kernel object

- [bedrock.nova_interface.predicates](./predicates.v): NOVA ghost state, generally by kernel object

- [bedrock.nova_interface.hypercall](./hypercall.v): logically atomic specs (ACs/AUs), generally by hypercall

These modules use NES namespace `nova` (e.g., `nova.ec.name` is the type of EC names).
Importing a higher layer pulls in all lower layers, e.g., `Require Import bedrock.nova_interface.hypercall` makes the type `nova.ec.name` (from the models layer) available.


***Importing less.***
Clients interested in a subset of some layer can pull in one of its submodules; for example,
```
Require Import bedrock.nova_interace.hypercall.ctrl_ec.
```
pulls in the AU/AC spec for the hypercall (called `nova.ctrl_ec.spec`) as well as all supporting NOVA predicates and models.



***Base modules.***
Each layer includes one or more "base" modules housing NOVA definitions that are pervasive to that layer:

- Hypercalls: ./hypercall/base.v (pervasives), ./hypercall/base_ipc.v (pervasives for IPC), ./hypercall/base_utcb.v (pervasives for UTCBs)

- Predicates: ./predicates/base.v (pervasives)

- Models: ./model/base.v (pervasives)


Module `bedrock.nova_interface.model.base`, for example, defines the type `nova.kobj_id` of kernel object identifiers while module `bedrock.nova_interface.model.ec` defines the alias `nova.ec.name := nova.kobj_id`.

The NOVA interface exports these base modules (e.g., module `bedrock.nova_interface.model` exports `bedrock.nova_interface.model.base`).
Moreover, individual user-facing modules in a layer export that layer's base, and the base module for a layer exports the base modules for lower layers (e.g., module `bedrock.nova_interface.hypercall.create_ec` exports `bedrock.nova_interface.hypercall.base` and also the predicate, model bases).



***Prelude modules.***
Each layer has an internal-use "prelude" module that is _not_ part of the NOVA interface and is _not_ exported by user-facing NOVA interface modules.
(A layer's prelude exports modules that are relevant to the other modules in the layer.)





## Module hierarchy of the operational semantics

We structure these specifications using Coq modules and module types, following
the pattern used by [Coq's number hierarchy](https://github.com/coq/coq/tree/V8.18.0/theories/Numbers).

We separate strictly module types stating assumptions to be later instantiated,
from "mixins", which are module types containing only definitions (which can be
`Include`d).
However, note Coq does not support true mixins, since it does not allow merging
axioms with satisfying definitions if both are included.

To avoid needing ML-style sharing constraints (which are unwieldy in Coq), and
allow linking, we combine heavy use of `Include` with full functorization:
- Each file should export a functor taking requirements to the combined
interface that implementors can fulfill.
- Linking would `Include` these functors in order; the key requirement is to
never duplicate definitions or axioms.

Next, we outline a (simplified) skeleton of module dependencies, which is essentially:
`opsem.isa <- (opsem.nova, opsem.cpu) <- nova_state_type`; other libraries
should depend on `Module Type NOVA_STATE_DEFS`.

`opsem.isa` exports:
```coq
Module Type OPSEM_ISA. (* [...] *)
Module Type OPSEM_ISA_FULL := OPSEM_ISA <+ OPSEM_ISA_GPR.
```

`opsem.nova` depends on `opsem.isa` and exports:
```coq
Module Type NOVA_ISA_BASE. (* [...   Include OPSEM_ISA. ... ] *)
Module Type NOVA_ISA_DERIVED (I : NOVA_ISA_BASE). (* [...] *)
Module Type NOVA_ISA := NOVA_ISA_BASE <+ NOVA_ISA_DERIVED.
```

For the above modules, pretty complete instantiations are possible, as they describe (parts of) the ISA-level spec.

`opsem.cpu` depends on `opsem.isa` and exports:
```coq
Module Type CPU_STS. (* [...] *)
Module Type CPU_REGS_DERIVED (I : OPSEM_ISA) (C : CPU_STS). (* [...] *)
Module Type CPU_REGS (I : OPSEM_ISA) := CPU_STS <+ CPU_REGS_DERIVED I.
```

`nova_state_type` depends on `opsem.cpu` and `opsem.nova`, and exports:
```coq
Module Type NOVA_STATE_DEFS (I : NOVA_ISA) (C : CPU_REGS I). (* [...] *)
```

<!-- The above uses UPPER_SNAKE_CASE for pure-axiom module types, and CamelCase for other modules and module types. -->

## Module hierarchy of the separation-logic spec.

The hierarchy is:
- `{nova_state_type, hypercall} <- wp_nova.ec`
- `nova_state <- nova_state_type`
- `predicates <- {nova_state, hypercall}`

A more detailed dependency graph is provided in [iface.dot](iface.dot).
