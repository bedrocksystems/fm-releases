#!/usr/bin/env bash

BRICK=BRiCk
NOVA=nova_interface

OPAM_SWITCH_NAME=$NOVA
OPAM_REPOS="iris-dev,default,coq-released"

# create opam switch
opam repo add --dont-select coq-released "https://coq.inria.fr/opam/released"
opam repo add --dont-select iris-dev "git+https://gitlab.mpi-sws.org/iris/opam.git"
opam switch create --empty --repositories=$OPAM_REPOS $OPAM_SWITCH_NAME

eval $(opam env)

# install cpp2v Coq library and Coq dependencies
opam pin add -n coq-lens.dev ./$BRICK/coq-lens/
opam pin add -n coq-lens-elpi.dev ./$BRICK/coq-lens/
opam pin add -n coq-elpi.2.0.2+bedrock+vanilla-coq https://github.com/rlepigre/coq-elpi/archive/refs/tags/v2.0.2+bedrock+vanilla-coq.tar.gz
opam pin add -n coq-cpp2v.dev ./$BRICK/

opam update

# opam dependencies for nova_interface
opam install --deps-only ./$NOVA/
