# The NOVA formal specification bundle

This file bundles a version of the NOVA formal specification (in
[`nova_interface`](./nova_interface/)) and a version of
[BRiCk](https://github.com/bedrocksystems/BRiCk) (in [`BRiCk`](./BRiCk/))
that the formal specification depends on.
(See the `version.*` files in each directory for the exact version.)

## How to build
- On the first time, use [`init.sh`](./init.sh) to build all dependencies of
  [`nova_interface`](./nova_interface/), including  [`BRiCk`](./BRiCk/).
  This will create a separate opam switch `nova_interface`. If you want to avoid
  that, feel free to edit the `init.sh` script.
- After running `init.sh`, you may need to run `eval $(opam env)` to make the
  newly installed packages visible.
- Afterwards, you should be able to run `dune build` in the
  [`nova_interface`](./nova_interface/) directory.

## How to use
- [`./nova_interface/nova_interface/README.md`](./nova_interface/nova_interface/README.md)
  describes the structure of the directory, and
  [`./nova_interface/nova_interface/iface.dot`](./nova_interface/nova_interface/iface.dot)
  provides a dependency graph of the components.
  (It can be built with `dot -Tpdf iface.dot > iface.pdf`)
- The source code is accompanied by a Technical Report.
- To browse the source code in your editor, please configure the editor to use
  the [`./nova_interface/_CoqProject`](./nova_interface/_CoqProject) file.
